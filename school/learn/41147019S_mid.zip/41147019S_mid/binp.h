#pragma once

#include <stdint.h>

int32_t isBinaryPalindrome(int32_t x);