#pragma once

#include <stdint.h>

double cal_n_derivatives( int32_t n, double a, int32_t size, int32_t coefficients[], int32_t powers[] );