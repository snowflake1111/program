#pragma once

int mymemcmp(const void *s1, const void *s2, size_t n);