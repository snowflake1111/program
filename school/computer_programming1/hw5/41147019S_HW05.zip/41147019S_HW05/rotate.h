#pragma once

// theta: in degree , not radian.
void rotate( double *x, double *y, double theta );
