#pragma once

#include <stdint.h>

double get_stddev( int32_t number );
