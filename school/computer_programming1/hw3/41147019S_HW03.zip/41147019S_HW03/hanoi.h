#pragma once

#include <stdint.h>

void step1(int32_t n, int32_t from, int32_t mid, int32_t to);
void step2(int32_t n);