#pragma once

#include <stdint.h>

int32_t setup( int32_t a, int32_t b, int32_t c);
double value( double x );
double min( double m, double n );
double max( double m, double n );
double slope( double t );
