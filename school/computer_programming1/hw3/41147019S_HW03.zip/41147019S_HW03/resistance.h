#pragma once

#include <stdint.h>

double calculate(int32_t r, int32_t n);